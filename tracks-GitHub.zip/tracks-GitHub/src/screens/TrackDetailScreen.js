import React from 'react';
import { View, StyleSheet, Text } from 'react-native';

const TrackDetailScreen = () => {
    return (
        <View>
            <Text style = {{ fontSize: 48 }}>TrackDetailScreen</Text>
        </View>
    );
};

const styles = StyleSheet.create({});

export default TrackDetailScreen;